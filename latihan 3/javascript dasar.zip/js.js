var text = 3343423 * 4454;
	function mouseover(){
		var x = document.querySelector('h1');
		x.innerHTML = text;
		x.style.backgroundColor = 'red';
		x.style.color = 'yellow';
}